package com.pockmarks.HEX.UI;

import java.awt.event.*;

class Menu implements ActionListener {
    HexUI hexUI;

    public Menu(HexUI HexUI) {
        this.hexUI = HexUI;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}